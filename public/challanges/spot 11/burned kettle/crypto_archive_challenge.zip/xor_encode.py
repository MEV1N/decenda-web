data=open("encoded/base64.txt").read().strip()
key="shadow_archive"

out=""

for i in range(len(data)):
    out+=chr(ord(data[i]) ^ ord(key[i % len(key)]))

print(out.encode().hex())
