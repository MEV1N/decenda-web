import base64

data=open("encoded/layer1.txt").read().strip()

encoded=base64.b85encode(bytes.fromhex(data))

print(encoded.decode())
