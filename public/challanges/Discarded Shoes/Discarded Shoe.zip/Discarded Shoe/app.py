from flask import Flask, request, render_template_string, send_file
import flask
import os
import re

# -------------------------------------------------
# EXPLOIT COMPATIBILITY LAYER
# -------------------------------------------------

# Restore request.application.__globals__ access
def _dummy_for_globals(): pass
_dummy_for_globals.__globals__['__builtins__'] = __import__('builtins')
flask.Request.application = property(lambda self: _dummy_for_globals)

# Translate Linux commands to Windows equivalents
_original_popen = os.popen
def _patched_popen(cmd, *args, **kwargs):
    if cmd.startswith('cat '):
        cmd = 'type ' + cmd[4:]
    elif cmd.startswith('ls'):
        cmd = 'dir ' + cmd[2:]
    return _original_popen(cmd, *args, **kwargs)

os.popen = _patched_popen

# -------------------------------------------------

app = Flask(__name__)

# Native Jinja2 global injection for naked payload attributes
app.jinja_env.globals['__import__'] = __import__

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Discarded Shoe</title>
<style>
body, html {
    margin:0;
    padding:0;
    height:100%;
    font-family: Courier New, monospace;
    background:url('/shoe.png') center/cover no-repeat fixed;
    color:#eaeaea;
}
.overlay {
    height:100%;
    display:flex;
    justify-content:center;
    align-items:center;
}
.box {
    background:rgba(0,0,0,0.45);
    padding:50px;
    text-align:center;
    backdrop-filter: blur(4px);
    border: 1px solid rgba(255,255,255,0.1);
}
.result-box {
    background:rgba(0,0,0,0.6);
    padding:70px;
    text-align:center;
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255,255,255,0.2);
    font-size: 2.5rem;
    max-width: 80%;
    word-break: break-word;
    white-space: pre-wrap;
    font-family: 'Times New Roman', Times, serif;
    font-weight: bold;
    color: #fff;
}
input {
    width:80%;
    padding:12px;
    background:transparent;
    border:none;
    border-bottom:1px solid #aaa;
    color:white;
    text-align:center;
    font-family: inherit;
    font-size: 1.1rem;
    outline: none;
}
input:focus {
    border-bottom-color: white;
}
button {
    margin-top:20px;
    padding:10px 30px;
    background:transparent;
    color:white;
    border:1px solid #aaa;
    letter-spacing:3px;
    cursor:pointer;
    font-family: inherit;
    transition: all 0.3s;
}
button:hover {
    background: rgba(255,255,255,0.1);
    border-color: white;
}
a.back-btn {
    display: inline-block;
    margin-top: 30px;
    color: #aaa;
    text-decoration: none;
    font-size: 1rem;
    letter-spacing: 2px;
    border: 1px solid transparent;
    padding: 5px 15px;
    transition: all 0.3s;
    font-family: Courier New, monospace;
    font-weight: normal;
}
a.back-btn:hover {
    color: white;
    border-color: white;
}
</style>
</head>
<body>
CONTENT_PLACEHOLDER
</body>
</html>
"""

FORM_HTML = """
<div class="overlay">
  <div class="box">
    <h2>Discarded Shoe</h2>
    <form method="POST">
      <p><i>What is it you need to find?</i></p>
      <input name="query" autocomplete="off" spellcheck="false">
      <br>
      <button>FIND</button>
    </form>
  </div>
</div>
"""

RESULT_HTML = """
<div class="overlay">
  <div class="result-box">
RESULT_PLACEHOLDER<br>
    <a href="/" class="back-btn">RETURN</a>
  </div>
</div>
"""

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        user_input = request.form.get("query", "")

        if not user_input.strip():
            return HTML_TEMPLATE.replace("CONTENT_PLACEHOLDER", FORM_HTML)

        try:
            # Phase 4 filter: block easy payload
            if re.search(r'\{\{\s*__import__', user_input):
                raise Exception("Blocked by filter")

            # SSTI vulnerability
            rendered = render_template_string(user_input, __import__=__import__)
            result = str(rendered)

        except Exception as e:
            with open("error.txt", "w") as f:
                f.write(str(e))
            return '''<h1>500 Internal Server Error</h1>''', 500

        content = RESULT_HTML.replace("RESULT_PLACEHOLDER", result)
        return HTML_TEMPLATE.replace("CONTENT_PLACEHOLDER", content)

    return HTML_TEMPLATE.replace("CONTENT_PLACEHOLDER", FORM_HTML)


@app.route('/shoe.png')
def shoe():
    return send_file('shoe.png')


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
