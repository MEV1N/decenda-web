from flask import Flask, request, render_template
from lxml import etree
from io import BytesIO

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/locker", methods=["POST"])
def locker():
    xml_data = request.data

    try:
        parser = etree.XMLParser(
            resolve_entities=True,
            load_dtd=True,
            no_network=False,
            huge_tree=True
        )

        # In order to make the CTF completely reliable on any host OS (like Windows),
        # we inject a custom resolver that fakes the `/etc/passwd` file!
        class CTFResolver(etree.Resolver):
            def resolve(self, url, pubid, context):
                if "etc/passwd" in url:
                    fake_passwd = (
                        "root:x:0:0:root:/root:/bin/bash\n"
                        "daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\n"
                        "archive:x:1001:1001:archive:/home/archive:/bin/sh\n"
                        "ctf:x:1004:1004:dec{acc3ss_w4s_r3m0v3d@mbc.ctf}\n"
                    )
                    return self.resolve_string(fake_passwd, context)
                return None
                
        parser.resolvers.add(CTFResolver())

        root = etree.parse(BytesIO(xml_data), parser).getroot()

        node = root.find("ID")

        if node is None:
            return "<pre>Locker response: Invalid request</pre>"

        # Extract all text including expanded entities. 
        # In lxml, system entities are practically invisible to regular .text iterations.
        # We MUST use etree.tostring string casting to force it to render the resolved entity.
        locker_value = etree.tostring(node, encoding='unicode', method='text').strip()

        return f"<pre>Locker response: {locker_value}</pre>"

    except Exception as e:
        return f"<pre>Error processing locker request</pre>"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
