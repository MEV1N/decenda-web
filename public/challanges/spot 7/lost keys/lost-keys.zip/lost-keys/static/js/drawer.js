document.querySelector("#drawerForm").addEventListener("submit", function (e) {
    e.preventDefault();

    fetch("/locker", {
        method: "POST",
        headers: {
            "Content-Type": window.contentType
        },
        body: payload(new FormData(this))
    })
        .then(res => res.text())
        .then(data => {
            document.getElementById("result").innerHTML = data;
        });
});
