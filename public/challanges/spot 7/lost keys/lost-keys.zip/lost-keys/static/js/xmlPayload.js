window.contentType = "application/xml";

function payload(data) {
    let xml = '<?xml version="1.0" encoding="UTF-8"?>';
    xml += "<data>";
    for (let pair of data.entries()) {
        let key = pair[0];
        let value = pair[1];
        xml += "<" + key + ">" + value + "</" + key + ">";
    }
    xml += "</data>";
    return xml;
}
